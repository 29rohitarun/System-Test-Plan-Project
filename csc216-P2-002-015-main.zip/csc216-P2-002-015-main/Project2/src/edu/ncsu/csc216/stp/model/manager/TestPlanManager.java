/**
 * 
 */
package edu.ncsu.csc216.stp.model.manager;

import java.io.File;

import edu.ncsu.csc216.stp.model.io.TestPlanReader;
import edu.ncsu.csc216.stp.model.io.TestPlanWriter;
import edu.ncsu.csc216.stp.model.test_plans.AbstractTestPlan;
import edu.ncsu.csc216.stp.model.test_plans.FailingTestList;
import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISortedList;
import edu.ncsu.csc216.stp.model.util.SortedList;

/**
 * TestPlanManager class handles the delegation to all of the other classes in
 * the project. It interacts with the IO classes. It manages the instance of
 * currentTestPlan
 * 
 * @author Rohit Arun
 *
 */
public class TestPlanManager {

	/** flag that keeps track of if the TestPlanManager has been changed */
	private boolean isChanged;
	/** List of TestPlans */
	private ISortedList<TestPlan> testPlans;
	/** FailingTestList field */
	private FailingTestList failingTestList;
	/** AbstractTestPlan field current test plan */
	private AbstractTestPlan currentTestPlan;

	/**
	 * Class constructor constructs testPlans as a SortedList. Constructs
	 * failingTsetList and sets currentTestPlan equal to it. Initializes isChanged
	 * to false
	 */
	public TestPlanManager() {
		clearTestPlans();
	}

	/**
	 * loads test plans from file by passing a file through the TestPlanReader class
	 * 
	 * @param file input file
	 */
	public void loadTestPlans(File file) {
		testPlans = TestPlanReader.readTestPlansFile(file);
		getFailingTests();
		setCurrentTestPlan(FailingTestList.FAILING_TEST_LIST_NAME);
		isChanged = true;

	}

	/**
	 * saves test plans to a file by passing file through the TestPlanWriter class
	 * 
	 * @param file output file
	 */
	public void saveTestPlans(File file) {
		TestPlanWriter.writeTestPlanFile(file, testPlans);
		isChanged = false; // Update boolean
	}

	/**
	 * returns boolean isChanged
	 * 
	 * @return isChanged if TestPlanManager has been changed since the last save.
	 */
	public boolean isChanged() {
		return isChanged;
	}

	/**
	 * Adds test plan to the list of TestPlans
	 * 
	 * @param testPlanName test plan name
	 * @throws IllegalArgumentException if name is FAILING_TEST_LIST_NAME or is
	 *                                  duplicate
	 */
	public void addTestPlan(String testPlanName) {
		// Failing Test check
		if (testPlanName.toLowerCase().equals(FailingTestList.FAILING_TEST_LIST_NAME.toLowerCase())) {
			throw new IllegalArgumentException("Invalid name.");
		}

		// duplicate check
		for (int i = 0; i < testPlans.size(); i++) {
			if (testPlans.get(i).getTestPlanName().toLowerCase().equals(testPlanName.toLowerCase())) {
				throw new IllegalArgumentException("Invalid name.");
			}
		}

		TestPlan tR = new TestPlan(testPlanName);
		testPlans.add(tR);
		setCurrentTestPlan(testPlanName);
		getFailingTests();
		isChanged = true;
	}

	/**
	 * returns test plan names in string array form for GUI
	 * 
	 * @return testPlanNames string array of TestPlan names
	 */
	public String[] getTestPlanNames() {

		String[] testPlanNames = new String[testPlans.size() + 1]; // Add 1 to size to account for failing test name
		testPlanNames[0] = FailingTestList.FAILING_TEST_LIST_NAME;
		for (int i = 0; i < testPlans.size(); i++) {
			testPlanNames[i + 1] = testPlans.get(i).getTestPlanName();
		}
		return testPlanNames;
	}

	/**
	 * Helper method for maintaining order and reconstructing failingTestList
	 */
	private void getFailingTests() {
		failingTestList.clearTests();

		for (int i = 0; i < testPlans.size(); i++) {
			for (int j = 0; j < testPlans.get(i).getTestCases().size(); j++) {
				if (!testPlans.get(i).getTestCase(j).isTestCasePassing()) {
					failingTestList.addTestCase(testPlans.get(i).getTestCase(j));
				}
			}
		}
	}

	/**
	 * returns currentTestPlan
	 * 
	 * @return currentTestPlan current test plan
	 */
	public AbstractTestPlan getCurrentTestPlan() {
		return currentTestPlan;
	}

	/**
	 * Sets the currentTestPlan to the AbstractTestPlan with the given name.
	 * 
	 * @param testPlanName the currentTestPlan to set
	 */
	public void setCurrentTestPlan(String testPlanName) {

		if (testPlanName.equals(FailingTestList.FAILING_TEST_LIST_NAME)) {
			currentTestPlan = failingTestList;
		}

		for (int i = 0; i < testPlans.size(); i++) {
			if (testPlanName.equals(testPlans.get(i).getTestPlanName())) {
				currentTestPlan = testPlans.get(i);
			}
		}

	}

	/**
	 * edits test plan name by removing and adding new name in place
	 * 
	 * @param testPlanName test plan name
	 * @throws IllegalArgumentException if currentTestPlan is a FailingTestList or
	 *                                  has the same name
	 */
	public void editTestPlan(String testPlanName) {

		// Check if current test plan is a failing one
		if (currentTestPlan.equals(failingTestList)) {
			throw new IllegalArgumentException("The Failing Tests list may not be edited.");
		}

		// Checks if the test plan name is failing one
		if (testPlanName.toLowerCase().equals(FailingTestList.FAILING_TEST_LIST_NAME.toLowerCase())) {
			throw new IllegalArgumentException("Invalid name.");
		}

		// Duplicate Check
		for (int i = 0; i < testPlans.size(); i++) {
			if (testPlans.get(i).getTestPlanName().toLowerCase().equals(testPlanName.toLowerCase())) {
				throw new IllegalArgumentException("Invalid name.");
			}
		}

		for (int i = 0; i < testPlans.size(); i++) {
			if (testPlans.get(i).getTestPlanName().equals(currentTestPlan.getTestPlanName())) {
				testPlans.remove(i);
			}
		}
		currentTestPlan.setTestPlanName(testPlanName);
		testPlans.add((TestPlan) currentTestPlan); // Cast currentTestPlan to type TestPlan
		getFailingTests();
		isChanged = true;

	}

	/**
	 * removes test plan and updates isChanged field
	 * 
	 * @throws IllegalArgumentException if currentTestPlan is a FailingTestList
	 */
	public void removeTestPlan() {

		// Check if current test plan is a failing one
		if (currentTestPlan.equals(failingTestList)) {
			throw new IllegalArgumentException("The Failing Tests list may not be deleted.");
		}

		for (int i = 0; i < testPlans.size(); i++) {
			if (testPlans.get(i) == currentTestPlan) {
				testPlans.remove(i);
			}
		}
		currentTestPlan = null;
		currentTestPlan = failingTestList;
		getFailingTests();
		isChanged = true;
	}

	/**
	 * Adds test case to TestPlan
	 * 
	 * @param testCase test case
	 */
	public void addTestCase(TestCase testCase) {

		if (currentTestPlan instanceof TestPlan) {
			currentTestPlan.addTestCase(testCase);

			getFailingTests(); // MIGHT BE WRONG. COME BACK AND CHECK

			isChanged = true;
		}
	}

	/**
	 * Adds the test result to the test case at the given index in the current test
	 * plan.
	 * 
	 * @param idx          desired index
	 * @param passing      whether test case is passing or not
	 * @param actualResult string of actual results
	 */
	public void addTestResult(int idx, boolean passing, String actualResult) {
		currentTestPlan.addTestResult(idx, passing, actualResult);

		// Updates Failing Test List if not passing
		if (!passing) {
			getFailingTests();
		}
	}

	/**
	 * Clears out the TestPlanManager by setting testPlans to an empty SortedList,
	 * failingTestList to an empty FailingTestList(), currentTestPlan to the
	 * failingTestList, and isChanged to false.
	 */
	public void clearTestPlans() {

		testPlans = new SortedList<TestPlan>();
		failingTestList = new FailingTestList();
		currentTestPlan = failingTestList;
		isChanged = false;
	}

}

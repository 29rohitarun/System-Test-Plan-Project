/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

/**
 * Swap List allows for unique movement of elements. Up or down one position.
 * Or, to the top or bottom of list
 * 
 * @param <E> generic type
 * @author Rohit Arun
 *
 */
public class SwapList<E> implements ISwapList<E> {

	/** generic array type log */
	private E[] log;
	/** size of list */
	private int size;
	/** initial capacity integer constant */
	private static final int INIT_CAPACITY = 10;

	/**
	 * constructs log by casting E to object
	 */
	@SuppressWarnings("unchecked")
	public SwapList() {
		log = (E[]) new Object[INIT_CAPACITY];
	}

	/**
	 * Adds the element to the end of the list.
	 * 
	 * @param element element to add
	 * @throws NullPointerException     if element is null
	 * @throws IllegalArgumentException if element cannot be added
	 */
	@Override
	public void add(E element) {

		try {
			// Null check
			if (element == null) {
				throw new NullPointerException("Cannot add null element.");
			}

			// Expands array capacity if the its size reaches the capacity
			if (this.size() == log.length) {
				growArray();
			}

			// Adding element at index: size(), so it is added to end of list
			log[this.size()] = element;

			// Increment size
			size++;

		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Cannot add element."); // If element can't be added
		}

	}

	/**
	 * Helper method for the ArrayList.add() method.
	 * 
	 * Doubles the capacity of the underlying array in order to make space for a new
	 * element.
	 */
	@SuppressWarnings("unchecked")
	private void growArray() {
		E[] temp = (E[]) new Object[2 * log.length];

		for (int i = 0; i < this.size(); i++) {
			temp[i] = log[i];
		}

		log = temp;
	}

	/**
	 * Returns the element from the given index. The element is removed from the
	 * list.
	 * 
	 * @param idx index to remove element from
	 * @return element at given index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public E remove(int idx) {

		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		// Store removed element in variable to return
		E removedElement = log[idx];

		// Shift all elements after removed elements to the left
		for (int i = idx; i < this.size() - 1; i++) {
			log[i] = log[i + 1];
		}

		size--; // Decrement size
		return removedElement;
	}

	/**
	 * Moves the element at the given index to index-1. If the element is already at
	 * the front of the list, the list is not changed.
	 * 
	 * @param idx index of element to move up
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public void moveUp(int idx) {
		E holder = null;
		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		// So that front of the list does not change
		if (idx != 0) {
			holder = log[idx - 1]; // Store value of previous element
			log[idx - 1] = log[idx]; // Set index-1 equal to index
			log[idx] = holder; // Replace original index with stored element
		}

	}

	/**
	 * Moves the element at the given index to index+1. If the element is already at
	 * the end of the list, the list is not changed.
	 * 
	 * @param idx index of element to move down
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public void moveDown(int idx) {
		E holder = null;
		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		// So that end of the list does not change
		if (idx != size() - 1) {
			holder = log[idx + 1]; // Store value of next element
			log[idx + 1] = log[idx]; // Set index+1 equal to index
			log[idx] = holder; // Replace original index with stored element
		}

	}

	/**
	 * Moves the element at the given index to index 0. If the element is already at
	 * the front of the list, the list is not changed.
	 * 
	 * @param idx index of element to move to the front
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public void moveToFront(int idx) {

		E holder = null;
		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		// So that end of the list does not change
		if (idx != 0) {
			holder = log[idx]; // Store value of desired element

			// Traverse through list and right shift elements
			for (int i = idx; i > 0; i--) {
				log[i] = log[i - 1];
			}
			log[0] = holder; // Set index 0 to stored element
		}
	}

	/**
	 * Moves the element at the given index to size-1. If the element is already at
	 * the end of the list, the list is not changed.
	 * 
	 * @param idx index of element to move to the back
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public void moveToBack(int idx) {

		E holder = null;
		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		// So that end of the list does not change
		if (idx != size() - 1) {
			holder = log[idx]; // Store value of desired element

			// Traverse through list and left shift elements
			for (int i = idx; i < size(); i++) {
				log[i] = log[i + 1];
			}
			log[size() - 1] = holder; // Set last index to stored element
		}
	}

	/**
	 * Returns the element at the given index.
	 * 
	 * @param idx index of the element to retrieve
	 * @return element at the given index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public E get(int idx) {

		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		return log[idx];
	}

	/**
	 * Returns the number of elements in the list.
	 * 
	 * @return number of elements in the list
	 */
	@Override
	public int size() {
		return size;
	}

}

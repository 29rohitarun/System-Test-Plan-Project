/**
 * 
 */
package edu.ncsu.csc216.stp.model.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.util.ISortedList;

/**
 * Writes TestPlan list contents onto output file in the required format
 * 
 * @author Rohit Arun
 *
 */
public class TestPlanWriter {

	/**
	 * writes TestPlans to file using the toString method from TestCase class
	 * 
	 * @param file     file to write to
	 * @param testPlan list of test plans
	 * @throws IllegalArgumentException if Unable to save file.
	 */
	public static void writeTestPlanFile(File file, ISortedList<TestPlan> testPlan) {

		try {
			PrintWriter fileWriter = new PrintWriter(file);

			for (int i = 0; i < testPlan.size(); i++) {
				fileWriter.println("! " + testPlan.get(i).getTestPlanName());
				for (int j = 0; j < testPlan.get(i).getTestCases().size(); j++) {
					fileWriter.print(testPlan.get(i).getTestCase(j).toString());
				}
			}
			fileWriter.close();

		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to save file.");
		}
	}

}

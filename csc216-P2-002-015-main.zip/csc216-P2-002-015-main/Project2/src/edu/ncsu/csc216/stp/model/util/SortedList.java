/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

/**
 * Constructs a generic list in sorted order. Extends Comparable and implements
 * ISortedList interface
 * 
 * @param <E> generic type
 * @author Rohit Arun
 *
 */
public class SortedList<E extends Comparable<E>> implements ISortedList<E> {

	/** size field that must be incremented or decremented when list is altered */
	private int size;
	/** field that points to the front of the list */
	private ListNode front;

	/**
	 * Adds the element to the list in sorted order.
	 * 
	 * @param element element to add
	 * @throws NullPointerException     if element is null
	 * @throws IllegalArgumentException if element cannot be added
	 */
	@Override
	public void add(E element) {

		// Null check
		if (element == null) {
			throw new NullPointerException("Cannot add null element.");
		}

		ListNode curr = this.front;

		// Duplicate check
		for (int i = 0; i < this.size(); i++) {
			if (curr != null) { // if current element in list is not null
				if (element.equals(curr.data)) { // check if it is equal to the parameter
					throw new IllegalArgumentException("Cannot add duplicate element.");
				}

				curr = curr.next;
			}
		}

		if (front == null || element.compareTo(front.data) < 0) { // If front is null or element is higher than front
																	// set the front to new element
			front = new ListNode(element, front);
		} else { // While next element is not null, loop through and stop before element that is
					// less than parameter
			ListNode current = front;
			while (current.next != null && current.next.data.compareTo(element) < 0) {
				current = current.next;
			}
			current.next = new ListNode(element, current.next); // Set next element to parameter
		}
		size++; // Increment size
	}

	/**
	 * Returns the element from the given index. The element is removed from the
	 * list.
	 * 
	 * @param idx index to remove element from
	 * @return element at given index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public E remove(int idx) {

		// Check if index is inside bounds
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		E value = null;

		// If the user wants to remove element at index 0
		if (idx == 0) {
			value = front.data; // value is set to the element at index 0
			front = front.next; // front is redirected to element after removed element.
		} else {
			ListNode curr = front;
			// Traverses list until element before desired element.
			for (int i = 0; i < idx - 1; i++) {
				curr = curr.next;
			}

			value = curr.next.data; // Value grabs the data from the next element since we stopped before it
			curr.next = curr.next.next; // the element before is altered to point to the element after the removed
										// element
		}

		// Decrement size
		size--;
		return value;
	}

	/**
	 * Returns true if the element is in the list.
	 * 
	 * @param element element to search for
	 * @return true if element is found
	 */
	@Override
	public boolean contains(E element) {

		ListNode current = front;

		if (front == null) { // If front is equal to null there are no elements
			return false;
		}

		if (size == 1 && current.data.equals(element)) { // If there is only 1 element in the list and it is equal to
															// parameter, return true
			return true;
		}

		while (current.next != null) {
			if (current.data.equals(element)) {
				return true;
			}
			current = current.next;
		}
		return false;
	}

	/**
	 * Returns the element at the given index.
	 * 
	 * @param idx index of the element to retrieve
	 * @return element at the given index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	@Override
	public E get(int idx) {
		// Check if index is inside bounds
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		E value = null;

		// If the user wants to remove element at index 0
		if (idx == 0) {
			value = front.data; // value is set to the element at index 0
		} else {
			ListNode curr = front;

			// Traverses list until element before desired element.
			for (int i = 0; i < idx - 1; i++) {
				curr = curr.next;
			}
			value = curr.next.data; // Value grabs the data from the next element since we stopped before it
		}
		return value;
	}

	/**
	 * Returns the number of elements in the list.
	 * 
	 * @return number of elements in the list
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Class used to point to next element. Structures the LinkedList
	 * 
	 * @author Rohit Arun
	 *
	 */
	private class ListNode {

		/** data that ListNode holds */
		public E data;
		/** pointer to the next ListNode */
		public ListNode next;

		/**
		 * Constructs ListNode with next reference
		 * 
		 * @param data the data that the ListNode holds
		 * @param next reference to the next ListNode in the list
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
	}

}

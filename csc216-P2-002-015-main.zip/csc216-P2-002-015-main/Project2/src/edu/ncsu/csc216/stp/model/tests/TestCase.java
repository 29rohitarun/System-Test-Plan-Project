/**
 * 
 */
package edu.ncsu.csc216.stp.model.tests;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.util.Log;

/**
 * TestCase class. Constructs a test case with its fields. The object is then
 * added to a list of TestCases for their respective TestPlan
 * 
 * @author Rohit Arun
 *
 */
public class TestCase {

	/** test case Id field */
	private String testCaseId;
	/** test type field */
	private String testType;
	/** test description field */
	private String testDescription;
	/** expected results field */
	private String expectedResults;
	/** test plan object field */
	private TestPlan testPlan;
	/** log of test results */
	private Log<TestResult> testResults;

	/**
	 * Constructs the class's fields. sets testPlan to null and initializes
	 * testResults as empty list
	 * 
	 * @param testCaseId      test case id
	 * @param testType        test type
	 * @param testDescription test description
	 * @param expectedResults expected results
	 */
	public TestCase(String testCaseId, String testType, String testDescription, String expectedResults) {
		setTestCaseId(testCaseId);
		setTestType(testType);
		setTestDescription(testDescription);
		setExpectedResults(expectedResults);
		this.testPlan = null;
		this.testResults = new Log<TestResult>();
	}

	/**
	 * gets testCaseId
	 * 
	 * @return testCaseId test case Id
	 */
	public String getTestCaseId() {
		return testCaseId;
	}

	/**
	 * sets testCaseId field to parameter
	 * 
	 * @param testCaseId the testCaseId to set
	 * @throws IllegalArgumentException if parameter is null or empty string
	 */
	private void setTestCaseId(String testCaseId) {
		// Null or empty string check
		if (testCaseId == null || "".equals(testCaseId)) {
			throw new IllegalArgumentException("Invalid test information.");
		}
		this.testCaseId = testCaseId;
	}

	/**
	 * gets testType
	 * 
	 * @return testType test type
	 */
	public String getTestType() {
		return testType;
	}

	/**
	 * sets testType field to parameter
	 * 
	 * @param testType the testType to set
	 * @throws IllegalArgumentException if parameter is null or empty string
	 */
	private void setTestType(String testType) {
		// Null or empty string check
		if (testType == null || "".equals(testType)) {
			throw new IllegalArgumentException("Invalid test information.");
		}
		this.testType = testType;
	}

	/**
	 * returns testDescription
	 * 
	 * @return testDescription test description
	 */
	public String getTestDescription() {
		return testDescription;
	}

	/**
	 * sets testDescription to parameter
	 * 
	 * @param testDescription the testDescription to set
	 * @throws IllegalArgumentException if parameter is null or empty string
	 */
	private void setTestDescription(String testDescription) {
		// Null or empty string check
		if (testDescription == null || "".equals(testDescription)) {
			throw new IllegalArgumentException("Invalid test information.");
		}
		this.testDescription = testDescription;
	}

	/**
	 * returns expectedResults
	 * 
	 * @return expectedResults expected results
	 */
	public String getExpectedResults() {
		return expectedResults;
	}

	/**
	 * sets expectedResults field to parameter
	 * 
	 * @param expectedResults the expectedResults to set
	 * @throws IllegalArgumentException if parameter is null or empty string
	 */
	private void setExpectedResults(String expectedResults) {
		// Null or empty string check
		if (expectedResults == null || "".equals(expectedResults)) {
			throw new IllegalArgumentException("Invalid test information.");
		}
		this.expectedResults = expectedResults;
	}

	/**
	 * Adds test result to list of test results
	 * 
	 * @param isPassing     boolean if passing or not
	 * @param actualResults actual results
	 * @throws IllegalArgumentException if TestResult can't be constructed
	 */
	public void addTestResult(boolean isPassing, String actualResults) {
		// Catch exception if TestResult can't be constructed
		try {
			TestResult tR = new TestResult(isPassing, actualResults); // Create new TestResult object
			testResults.add(tR); // Add the object to the testResults list
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid test results.");
		}

	}

	/**
	 * returns if true if test case is passing. False if it is not passing
	 * 
	 * @return true or false
	 */
	public boolean isTestCasePassing() {
		// If list is empty return false
		if (testResults.size() == 0) {
			return false;
		}

		// If last test result in the list is passing return true else return false
		return testResults.get(testResults.size() - 1).isPassing();

	}

	/**
	 * returns status of test cases
	 * 
	 * @return PASS or FAIL constants
	 */
	public String getStatus() {
		// Return constants from TestResult
		if (isTestCasePassing()) {
			return TestResult.PASS;
		} else {
			return TestResult.FAIL;
		}
	}

	/**
	 * Returns a string representation of the testResults Log
	 * 
	 * @return retValue string of testResults
	 */
	public String getActualResultsLog() {
		String retValue = "";

		// For each element in testResults, print a dash and new line before and after
		for (int i = 0; i < testResults.size(); i++) {
			retValue += "- ";
			retValue += testResults.get(i).toString();
			retValue += "\n";
		}
		return retValue;
	}

	/**
	 * sets testPlan field to parameter
	 * 
	 * @param testPlan the testPlan to set
	 * @throws IllegalArgumentException if parameter is null
	 */
	public void setTestPlan(TestPlan testPlan) {
		// Null check
		if (testPlan == null) {
			throw new IllegalArgumentException("Invalid test plan.");
		}

		this.testPlan = testPlan;
	}

	/**
	 * gets the testPlan
	 * 
	 * @return testPlan test plan
	 */
	public TestPlan getTestPlan() {
		return testPlan;
	}

	/**
	 * converts Test Cases to string
	 * 
	 * @return String of Test Case
	 */
	public String toString() {

		return "# " + testCaseId + "," + testType + "\n" + "* " + testDescription + "\n" + "* " + expectedResults + "\n"
				+ getActualResultsLog();
	}

}

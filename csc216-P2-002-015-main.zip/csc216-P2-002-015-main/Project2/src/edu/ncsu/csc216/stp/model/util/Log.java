/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

/**
 * Log class implements the ILog interface to construct an array based list that
 * adds elements to the end of the list without being able to remove them.
 * 
 * The get method retrieves an element at a specified index.
 * 
 * @param <E> generic type
 * @author Rohit Arun
 *
 */
public class Log<E> implements ILog<E> {

	/** Generic array type log */
	private E[] log;
	/** Size of array */
	private int size;
	/** Constant for the initial capacity of the array */
	private static final int INIT_CAPACITY = 10;

	/**
	 * Constructs log by casting generic object to specified type
	 */
	@SuppressWarnings("unchecked")
	public Log() {
		log = (E[]) new Object[INIT_CAPACITY];
	}

	/**
	 * Adds the element to the end of the list.
	 * 
	 * @param element element to add
	 * @throws NullPointerException if element is null
	 */
	public void add(E element) {
		// Null check
		if (element == null) {
			throw new NullPointerException("Cannot add null element.");
		}

		// Expands array capacity if the its size reaches the capacity
		if (this.size() == log.length) {
			growArray();
		}

		// Adding element at index: size(), so it is added to end of list
		log[this.size()] = element;

		// Increment size
		size++;
	}

	/**
	 * Helper method for the ArrayList.add() method.
	 * 
	 * Doubles the capacity of the underlying array in order to make space for a new
	 * element.
	 */
	@SuppressWarnings("unchecked")
	private void growArray() {
		E[] temp = (E[]) new Object[2 * log.length];

		for (int i = 0; i < this.size(); i++) {
			temp[i] = log[i];
		}

		log = temp;
	}

	/**
	 * Returns the element at the given index.
	 * 
	 * @param idx index of the element to retrieve
	 * @return element at the given index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	public E get(int idx) {
		// Check if index is within the bounds of the array
		if (idx < 0 || this.size() <= idx) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		return log[idx];
	}

	/**
	 * Returns the number of elements in the list.
	 * 
	 * @return size number of elements in the list
	 */
	public int size() {
		return size;
	}

}

/**
 * 
 */
package edu.ncsu.csc216.stp.model.tests;

/**
 * Constructs TestResult object which is associated with its respective TestCase
 * 
 * @author Rohit Arun
 *
 */
public class TestResult {

	/** constant variable for passed test */
	public static final String PASS = "PASS";
	/** constant variable for failed test */
	public static final String FAIL = "FAIL";
	/** boolean if passing or not */
	private boolean passing;
	/** field for actual results */
	private String actualResults;

	/**
	 * TestResult constructors sets passing boolean and actual results
	 * 
	 * @param passing       boolean if passing or not
	 * @param actualResults actual results of test
	 */
	public TestResult(boolean passing, String actualResults) {

		setPassing(passing);
		setActualResults(actualResults);
	}

	/**
	 * gets the actualResults
	 * 
	 * @return actualResults actual results
	 */
	public String getActualResults() {
		return actualResults;
	}

	/**
	 * sets the actualResults
	 * 
	 * @param actualResults the actualResults to set
	 */
	private void setActualResults(String actualResults) {

		if (actualResults == null || "".equals(actualResults)) {
			throw new IllegalArgumentException("Invalid test results.");
		}

		this.actualResults = actualResults;
	}

	/**
	 * returns if passing or not
	 * 
	 * @return passing true or false
	 */
	public boolean isPassing() {
		return passing;
	}

	/**
	 * sets passing field to parameter
	 * 
	 * @param passing parameter to set field to
	 */
	private void setPassing(boolean passing) {
		this.passing = passing;
	}

	/**
	 * Converts to string
	 * 
	 * @return PASS or FAILS
	 */
	@Override
	public String toString() {

		// If the isPassing method returns true return PASS: . Else return FAIL:
		if (isPassing()) {
			return PASS + ": " + actualResults;
		} else {
			return FAIL + ": " + actualResults;
		}
	}

}

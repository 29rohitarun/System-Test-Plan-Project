/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import java.util.Objects;

import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISwapList;
import edu.ncsu.csc216.stp.model.util.SwapList;

/**
 * Super class of FailingTestList and TestPlan class. Adds Test Cases, Test
 * Plans, and Test Results
 * 
 * @author Rohit Arun
 *
 */
public abstract class AbstractTestPlan {

	/** test plan name field */
	private String testPlanName;
	/** list of test cases */
	private SwapList<TestCase> testCases;

	/**
	 * Class constructor. Sets the fields from the parameters and constructs a
	 * SwapList for the TestCases
	 * 
	 * @param testPlanName test plan name
	 * @throws IllegalArgumentException if testPlanName is null or empty
	 */
	public AbstractTestPlan(String testPlanName) {

		// Check if testPlanName is null or empty string
		if (testPlanName == null || "".equals(testPlanName)) {
			throw new IllegalArgumentException("Invalid name.");
		}

		testCases = new SwapList<TestCase>(); // Construct empty SwapList
		setTestPlanName(testPlanName); // Set field to parameter
	}

	/**
	 * sets testPlanName field to parameter
	 * 
	 * @param testPlanName test plan name
	 * @throws IllegalArgumentException if testPlanName is null or empty
	 */
	public void setTestPlanName(String testPlanName) {
		// Null or empty string check
		if (testPlanName == null || "".equals(testPlanName)) {
			throw new IllegalArgumentException("Invalid name.");
		}
		this.testPlanName = testPlanName;
	}

	/**
	 * returns testPlanName
	 * 
	 * @return testPlanName test plan name
	 */
	public String getTestPlanName() {
		return testPlanName;
	}

	/**
	 * returns test cases
	 * 
	 * @return testCases test cases
	 */
	public ISwapList<TestCase> getTestCases() {
		return testCases;
	}

	/**
	 * adds test case to the list of TestCases
	 * 
	 * @param testCase test case
	 * @throws NullPointerException     if element is null
	 * @throws IllegalArgumentException if element cannot be added
	 */
	public void addTestCase(TestCase testCase) {
		testCases.add(testCase);
	}

	/**
	 * Removes test case from TestPlan
	 * 
	 * @param idx index
	 * @return removedElement removed test case
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	public TestCase removeTestCase(int idx) {
		return testCases.remove(idx);
	}

	/**
	 * Gets the test case from the test plan
	 * 
	 * @param idx index
	 * @return test case at index
	 * @throws IndexOutOfBoundsException if the idx is out of bounds for the list
	 */
	public TestCase getTestCase(int idx) {
		return testCases.get(idx);
	}

	/**
	 * gets number of failing tests
	 * 
	 * @return counter number of failing tests
	 */
	public int getNumberOfFailingTests() {
		int counter = 0;
		// Parse through list and increment counter if test is failing
		for (int i = 0; i < testCases.size(); i++) {
			if (!testCases.get(i).isTestCasePassing()) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * Adds test results to its respective test case using the index
	 * 
	 * @param idx           index of desired element
	 * @param passing       if test case is passing or not
	 * @param actualResults actual results
	 * @throws IllegalArgumentException if TestResult can't be constructed
	 */
	public void addTestResult(int idx, boolean passing, String actualResults) {

		testCases.get(idx).addTestResult(passing, actualResults);
	}

	/**
	 * 
	 * returns 2D array of test cases
	 * 
	 * @return testCaseArray array of test cases
	 */
	public abstract String[][] getTestCasesAsArray();

	/**
	 * hashCode method hashes testPlanName
	 * 
	 * @return hashed testPlanName
	 */
	@Override
	public int hashCode() {
		return Objects.hash(testPlanName);
	}

	/**
	 * equals method compares this testPlanName to the parameter object's
	 * testPlanName
	 * 
	 * @param obj Object
	 * @return result of equality check
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof AbstractTestPlan))
			return false;
		AbstractTestPlan other = (AbstractTestPlan) obj;
		return Objects.equals(testPlanName.toLowerCase(), other.testPlanName.toLowerCase());
	}

}

/**
 * 
 */
package edu.ncsu.csc216.stp.model.io;

import java.io.File;
import java.util.Scanner;

import edu.ncsu.csc216.stp.model.test_plans.AbstractTestPlan;
import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.tests.TestResult;
import edu.ncsu.csc216.stp.model.util.ISortedList;
import edu.ncsu.csc216.stp.model.util.SortedList;

/**
 * Reads in TestPlans from input file and constructs list from input
 * 
 * @author Rohit Arun
 *
 */
public class TestPlanReader {

	/**
	 * Reads File and uses a scanner object to load files contents onto a string
	 * which is passed to helper methods
	 * 
	 * @param file input file
	 * @return testPlanList list of TestPlans read from file
	 * @throws IllegalArgumentException if unable to load file
	 */
	public static ISortedList<TestPlan> readTestPlansFile(File file) {
		SortedList<TestPlan> testPlanList = new SortedList<TestPlan>();
		Scanner fileReader;
		String stringOfFile = "";
		String stringOfPlan = "";
		TestPlan tP = null;

		try {
			fileReader = new Scanner(file);
		} catch (Exception e) {
			throw new IllegalArgumentException("Unable to load file.");
		}

		while (fileReader.hasNextLine()) {
			stringOfFile += fileReader.nextLine();
			stringOfFile += "\n";
		}
		fileReader.close();

		if ('!' != stringOfFile.charAt(0)) {
			throw new IllegalArgumentException("Unable to load file.");
		}

		Scanner scnrOfPlan = new Scanner(stringOfFile);
		scnrOfPlan.useDelimiter("\\r?\\n?[!]");
		while (scnrOfPlan.hasNext()) {
			stringOfPlan = scnrOfPlan.next();
			System.out.println(stringOfPlan);
			tP = processTestPlan(stringOfPlan);
			testPlanList.add(tP);
		}
		scnrOfPlan.close();
		return testPlanList;

	}

	/**
	 * Separates the Test Plans with the passed string from readTestPlansFile()
	 * method
	 * 
	 * @param plan string of file
	 * @return tP TestPlan of TestCase's
	 */
	private static TestPlan processTestPlan(String plan) {
		String extractName = "";
		String stringOfTestCases = "";
		Scanner scnrOfCases = new Scanner(plan);
		TestCase tC = null;

		scnrOfCases.useDelimiter("\\r?\\n?[#]");

		extractName = scnrOfCases.nextLine();
		extractName = extractName.substring(1);
		extractName = extractName.trim();

		System.out.println("Name: " + extractName);
		TestPlan tP = new TestPlan(extractName);

		while (scnrOfCases.hasNext()) {
			stringOfTestCases = scnrOfCases.next();
			stringOfTestCases = stringOfTestCases.trim();
			tC = processTest(tP, stringOfTestCases);

			if (tC != null) {
				tP.addTestCase(tC);
			}
		}
		scnrOfCases.close();
		return tP;
	}

	/**
	 * Processes the Test Cases and constructs TestCase objects from what the method
	 * reads in from the file.
	 * 
	 * @param o              AbstractTestPlan
	 * @param testPlanString String of test plan
	 * @return TC test case object
	 */
	private static TestCase processTest(AbstractTestPlan o, String testPlanString) {
		String testCaseId = null;
		String testType = null;
		String testDescription = null;
		String expectedResults = null;
		String results = null;
		String isPassing = null;
		String actualResults = null;
		boolean result = false;
		TestCase tC = null;

		try {
			Scanner split = null;
			// System.out.println("Dashes: " + dashDelimeter);

			Scanner scnr = new Scanner(testPlanString);
			scnr.useDelimiter(",");

			testCaseId = scnr.next();
			testCaseId = testCaseId.trim();
			// System.out.println("id: " + testCaseId);

			testType = scnr.nextLine();
			testType = testType.substring(1);
			testType = testType.trim();
			// System.out.println("TT: " + testType);

			scnr.useDelimiter("\\r?\\n?[*]");
			testDescription = scnr.next();
			testDescription = testDescription.trim();
			// System.out.println("TD: " + testDescription);
			scnr.useDelimiter("\\r?\\n?[-]");
			expectedResults = scnr.next();
			expectedResults = expectedResults.substring(2);
			expectedResults = expectedResults.trim();
			// System.out.println("ER: " + expectedResults);

			tC = new TestCase(testCaseId, testType, testDescription, expectedResults);

			while (scnr.hasNext()) {
				results = scnr.next();
				results = results.substring(1);
				split = new Scanner(results);
				split.useDelimiter(":");

				if (!split.hasNext()) {
					split.close();
					tC = null;
					return tC;
				}

				isPassing = split.next();
				isPassing = isPassing.trim();

				if (!split.hasNext()) {
					split.close();
					tC = null;
					return tC;
				}

				actualResults = split.next();
				actualResults = actualResults.trim();

				if ("".equals(actualResults) || actualResults == null) {
					split.close();
					tC = null;
					return tC;
				}

				if (isPassing.equals(TestResult.FAIL)) {
					result = false;
					tC.addTestResult(result, actualResults);
				} else if (isPassing.equals(TestResult.PASS)) {
					result = true;
					tC.addTestResult(result, actualResults);
				} else {
					split.close();
					tC = null;
					return tC;
				}
			}
			scnr.close();
			split.close();

		} catch (Exception e) {
			// Do nothing
		}
		return tC;
	}
}

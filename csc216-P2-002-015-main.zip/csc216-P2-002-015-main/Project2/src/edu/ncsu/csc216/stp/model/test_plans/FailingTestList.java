/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISwapList;

/**
 * Constructs list of failing tests
 * 
 * @author Rohit Arun
 *
 */
public class FailingTestList extends AbstractTestPlan {

	/** Failing Tests string constant */
	public static final String FAILING_TEST_LIST_NAME = "Failing Tests";

	/**
	 * constructs failing test list name to the test plan name
	 */
	public FailingTestList() {
		super(FAILING_TEST_LIST_NAME);
	}

	/**
	 * adds failing test case through the super class's addTestCase method
	 * 
	 * @param testCase test case
	 * @throws IllegalArgumentException if testCase is not failing
	 */
	@Override
	public void addTestCase(TestCase testCase) {
		if (!testCase.isTestCasePassing()) {
			super.addTestCase(testCase);
		} else {
			throw new IllegalArgumentException("Cannot add passing test case.");
		}
	}

	/**
	 * sets test plan name to Failing Test List Name constant field
	 * 
	 * @throws IllegalArgumentException if parameter value does not match expected
	 *                                  name
	 */
	@Override
	public void setTestPlanName(String testPlanName) {

		// Check if the testPlanName is equal to the failing test plan name
		if (!testPlanName.toLowerCase().equals(FAILING_TEST_LIST_NAME.toLowerCase())) {
			throw new IllegalArgumentException("The Failing Tests list cannot be edited.");
		}

		super.setTestPlanName(FAILING_TEST_LIST_NAME);
	}

	/**
	 * gets test cases as 2D array. Test case Id, test type, and test plan name
	 * populate the array
	 */
	@Override
	public String[][] getTestCasesAsArray() {
		// Since field is private and not accessible, set new variable equal to return
		// value of getter method
		ISwapList<TestCase> testCases = super.getTestCases();

		// Nested for-loop to populate 2-D array with test case Id, test type, and
		// status
		String[][] testCaseArray = new String[testCases.size()][3];

		// THERE COULD BE A DIFFERENT IMPLEMENTATION SPECIALIZED FOR SIZE = 1. CHECK
		// BACK IF
		// NEEDED
		if (testCases != null) { // Null check
			for (int i = 0; i < testCaseArray.length; i++) {
				for (int j = 0; j < testCaseArray[i].length; j++) {
					testCaseArray[i][0] = testCases.get(i).getTestCaseId();
					testCaseArray[i][1] = testCases.get(i).getTestType();
					if (testCases.get(i).getTestPlan() != null) {
						testCaseArray[i][2] = testCases.get(i).getTestPlan().getTestPlanName();
					} else {
						testCaseArray[i][2] = "";
					}
				}
			}
		}
		return testCaseArray;
	}

	/**
	 * clears tests by removing all elements in the list
	 */
	public void clearTests() {

		// Goes through every element and removes all failing test cases from list
		for (int i = super.getTestCases().size(); i-- > 0;) {
			super.removeTestCase(i);
		}

	}

}

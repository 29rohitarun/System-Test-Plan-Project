/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISwapList;

/**
 * Constructs a test plan that holds TestCases
 * 
 * @author Rohit Arun
 *
 */
public class TestPlan extends AbstractTestPlan implements Comparable<TestPlan> {

	/**
	 * Constructs the TestPlan with the given name
	 * 
	 * @param testPlanName test plan name
	 * @throws IllegalArgumentException if proposed name is the same as failing test
	 *                                  list name
	 */
	public TestPlan(String testPlanName) {
		super(testPlanName);

		if (testPlanName.toLowerCase().equals(FailingTestList.FAILING_TEST_LIST_NAME.toLowerCase())) {
			throw new IllegalArgumentException("Invalid name.");
		}
	}

	/**
	 * returns testCases as a 2D array populated with test case Id, test type, and
	 * test status
	 * 
	 * @return testCaseArray 2D array of test cases
	 */
	public String[][] getTestCasesAsArray() {
		// Since field is private and not accessible, set new variable equal to return
		// value of getter method
		ISwapList<TestCase> testCases = super.getTestCases();

		// Nested for-loop to populate 2-D array with test case Id, test type, and
		// status
		String[][] testCaseArray = new String[testCases.size()][3];

		// THERE MIGHT BE A DIFFERENT IMPLEMENTATION SPECIALIZED FOR SIZE = 1. CHECK
		// BACK IF
		// NEEDED
		if (testCases != null) { // Null check
			for (int i = 0; i < testCaseArray.length; i++) {
				for (int j = 0; j < testCaseArray[i].length; j++) {
					testCaseArray[i][0] = testCases.get(i).getTestCaseId();
					testCaseArray[i][1] = testCases.get(i).getTestType();
					testCaseArray[i][2] = testCases.get(i).getStatus();
				}
			}
		}
		return testCaseArray;
	}

	/**
	 * adds test case to to list of test cases through the super class's addTestCase
	 * method
	 * 
	 * @param testCase test case
	 */
	@Override
	public void addTestCase(TestCase testCase) {
		super.addTestCase(testCase); // MAYBE WRONG. DOUBLE CHECK
		testCase.setTestPlan(this);
	}

	/**
	 * compares test plan names from parameter and super's instance
	 * 
	 * @param o test plan object
	 * @return retValue integer indicating if parameter's test plan name is less
	 *         than or greater than super's instance
	 */
	@Override
	public int compareTo(TestPlan o) {
		// Comparing testPlanName field from super class to testPlanName from parameter
		int retValue = super.getTestPlanName().toLowerCase().compareTo(o.getTestPlanName().toLowerCase());
		return retValue;
	}

}

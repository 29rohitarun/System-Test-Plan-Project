/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.tests.TestCase;

/**
 * Tests AbstractTestPlan abstract class
 * 
 * @author Rohit Arun
 *
 */
class AbstractTestPlanTest {

	/**
	 * Test AbstractTestPlan constructor
	 */
	@Test
	void testAbstractTestPlan() {

		try {
			AbstractTestPlan aTP = new TestPlan("");
			aTP.getTestPlanName();
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

		try {
			AbstractTestPlan aTP1 = new TestPlan(null);
			aTP1.getTestPlanName();
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

		AbstractTestPlan aTP2 = new TestPlan("WolfScheduler");
		assertEquals("WolfScheduler", aTP2.getTestPlanName());

		try {
			aTP2.setTestPlanName(null);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

	}

	/**
	 * Tests getTestCases, addTestCase, removeTestCase, and getTestCase methods
	 */
	@Test
	void testTestCases() {

		AbstractTestPlan aTP = new TestPlan("WolfScheduler");
		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		TestCase tC1 = new TestCase("id1", "type", "descrip", "exp");
		TestCase tC2 = new TestCase("id2", "type", "descrip", "exp");
		TestCase tC3 = new TestCase("id3", "type", "descrip", "exp");

		aTP.addTestCase(tC);
		aTP.addTestCase(tC1);
		aTP.addTestCase(tC2);
		aTP.addTestCase(tC3);

		assertEquals(4, aTP.getTestCases().size());
		assertEquals("id1", aTP.getTestCases().get(1).getTestCaseId());

		assertEquals(tC2, aTP.removeTestCase(2));
		assertEquals(tC3, aTP.getTestCase(2));

	}

	/**
	 * Tests getNumberOfFailingTests method and addTestResult method
	 */
	@Test
	void testGetNumberOfFailingTests() {

		AbstractTestPlan aTP = new TestPlan("WolfScheduler");
		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		TestCase tC1 = new TestCase("id1", "type", "descrip", "exp");
		TestCase tC2 = new TestCase("id2", "type", "descrip", "exp");
		TestCase tC3 = new TestCase("id3", "type", "descrip", "exp");

		aTP.addTestCase(tC);
		aTP.addTestCase(tC1);
		aTP.addTestCase(tC2);
		aTP.addTestCase(tC3);

		aTP.addTestResult(0, false, "actual");
		aTP.addTestResult(1, true, "actual");
		aTP.addTestResult(2, false, "actual");
		aTP.addTestResult(3, false, "actual");

		assertEquals(3, aTP.getNumberOfFailingTests());

	}
}

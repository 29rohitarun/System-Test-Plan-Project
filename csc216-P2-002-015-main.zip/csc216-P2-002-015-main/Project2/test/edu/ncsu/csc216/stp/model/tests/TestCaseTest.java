/**
 * 
 */
package edu.ncsu.csc216.stp.model.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests the TestCase class
 * 
 * @author Rohit Arun
 *
 */
class TestCaseTest {

	/**
	 * Test TestCase constructor
	 */
	@Test
	void testTestCase() {

		// test construction
		TestCase tC = new TestCase("id", "type", "description", "expected");
		assertNotNull(tC);
		// test setters and getters
		assertEquals(tC.getTestCaseId(), "id");
		assertEquals(tC.getTestType(), "type");
		assertEquals(tC.getTestDescription(), "description");
		assertEquals(tC.getExpectedResults(), "expected");
		// test invalid TestCaseId (null)
		try {
			tC = new TestCase(null, "type", "description", "expected");
			fail();
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
		}
		// test invalid TestType (null)
		try {
			tC = new TestCase("id", null, "description", "expected");
			fail();
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
		}
		// test invalid test Description
		try {
			tC = new TestCase("id", "type", null, "expected");
			fail();
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
		}
		// test invalid expected result (null)
		try {
			tC = new TestCase("id", "type", "description", null);
			fail();
		} catch (IllegalArgumentException e) {
			assertNotNull(e.getMessage());
		}
	}

	/**
	 * Test addTestResult method
	 */
	@Test
	void testSetTestPlan() {
		TestCase tC = new TestCase("id", "type", "description", "expected");

		try {
			tC.setTestPlan(null);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid test plan.", e.getMessage());
		}

	}

}

/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.tests.TestCase;

/**
 * Tests FailingTestList class
 * 
 * @author Rohit Arun
 *
 */
class FailingTestListTest {

	/**
	 * Tests FailingTestList's addTestCase method
	 */
	@Test
	void testAddTestCase() {
		FailingTestList fTL = new FailingTestList();

		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		tC.addTestResult(false, "actual");
		TestCase tC1 = new TestCase("id1", "type", "descrip", "exp");
		tC1.addTestResult(true, "actual");
		TestCase tC2 = new TestCase("id2", "type", "descrip", "exp");
		tC2.addTestResult(false, "actual");
		TestCase tC3 = new TestCase("id3", "type", "descrip", "exp");
		tC3.addTestResult(false, "actual");

		fTL.addTestCase(tC);
		assertEquals(1, fTL.getTestCases().size());

		try {
			fTL.addTestCase(tC1);
			fail();
		} catch (Exception e) {
			assertEquals("Cannot add passing test case.", e.getMessage());
		}

		fTL.addTestCase(tC2);
		assertEquals(2, fTL.getTestCases().size());

		fTL.addTestCase(tC3);
		assertEquals(3, fTL.getTestCases().size());
	}

	/**
	 * Tests FailingTestList's setTestPlan method
	 */
	@Test
	void testSetTestPlanName() {
		FailingTestList fTL = new FailingTestList();

		try {
			fTL.setTestPlanName("Invalid");
			fail();
		} catch (Exception e) {
			assertEquals("The Failing Tests list cannot be edited.", e.getMessage());
		}

		fTL.setTestPlanName("Failing Tests");
		assertEquals("Failing Tests", fTL.getTestPlanName());
	}

	/**
	 * Tests FailingTestList's getTestCasesAsArray method
	 */
	@Test
	void testGetTestCasesAsArray() {

		FailingTestList fTL = new FailingTestList();
		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		TestPlan tP = new TestPlan("WolfScheduler");
		fTL.addTestCase(tC);
		fTL.getTestCasesAsArray();
		tC.setTestPlan(tP);

		assertEquals("id", fTL.getTestCasesAsArray()[0][0]);
		assertEquals("type", fTL.getTestCasesAsArray()[0][1]);
		assertEquals("WolfScheduler", fTL.getTestCasesAsArray()[0][2]);
	}

	/**
	 * Tests FailingTestList's addTestCase method replicating jenkins TS test
	 */
	@Test
	void testAddTestCaseJenkins() {
		FailingTestList fTL = new FailingTestList();

		TestCase tC1 = new TestCase("ID1", "type1", "description1", "expected1");
		tC1.addTestResult(false, "actual");
		TestCase tC2 = new TestCase("ID2", "type2", "description2", "expected2");
		tC2.addTestResult(true, "actual");
		TestCase tC3 = new TestCase("ID3", "type3", "description3", "expected3");
		tC3.addTestResult(false, "actual");
		TestCase tC4 = new TestCase("ID4", "type4", "description4", "expected4");
		tC4.addTestResult(false, "actual");

		fTL.addTestCase(tC1);

		try {
			fTL.addTestCase(tC2);
		} catch (Exception e) {
			assertEquals("Cannot add passing test case.", e.getMessage());
		}
		fTL.addTestCase(tC3);
		fTL.addTestCase(tC4);

		assertEquals(3, fTL.getNumberOfFailingTests());
		fTL.clearTests();
		
		assertEquals(0, fTL.getNumberOfFailingTests());
	}
}

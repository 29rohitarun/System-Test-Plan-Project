/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests SwapList class 
 * 
 * @author Rohit Arun
 *
 */
class SwapListTest {

	/**
	 * Tests add, remove, and get methods of SwapList class
	 */
	@Test
	void testSwapList() {
		SwapList<String> sL = new SwapList<String>();

		try {
			sL.add(null);
			fail();
		} catch (Exception e) {
			assertEquals("Cannot add null element.", e.getMessage());
		}

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		assertEquals("WolfScheduler", sL.remove(0));
		assertEquals("AnnaPlanner", sL.remove(2));

		try {
			sL.remove(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		assertEquals("WolfPackScheduler", sL.get(1));
	}

	/**
	 * Tests moveUp method
	 */
	@Test
	void testMoveUp() {
		SwapList<String> sL = new SwapList<String>();

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		try {
			sL.moveUp(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		sL.moveUp(3);
		assertEquals("AnnaPlanner", sL.get(2));
	}

	/**
	 * Tests moveDown method
	 */
	@Test
	void testMoveDown() {
		SwapList<String> sL = new SwapList<String>();

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		try {
			sL.moveDown(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		sL.moveDown(2);
		assertEquals("WolfPackScheduler", sL.get(3));
	}

	/**
	 * Tests moveToFront method
	 */
	@Test
	void testMoveToFront() {
		SwapList<String> sL = new SwapList<String>();

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		try {
			sL.moveToFront(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		sL.moveToFront(2);
		assertEquals("WolfPackScheduler", sL.get(0));
	}

	/**
	 * Tests moveToBack method
	 */
	@Test
	void testMoveToBack() {
		SwapList<String> sL = new SwapList<String>();

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		try {
			sL.moveToBack(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		sL.moveToBack(2);
		assertEquals("WolfPackScheduler", sL.get(3));
	}

	/**
	 * Tests moveUp method
	 */
	@Test
	void testGrowArray() {
		SwapList<String> sL = new SwapList<String>();

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		assertEquals("PackScheduler", sL.get(1));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(3));

		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");
		sL.add("AnnaPlanner");

		assertEquals(11, sL.size());

	}
}

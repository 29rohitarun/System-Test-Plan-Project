/**
 * 
 */
package edu.ncsu.csc216.stp.model.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Test TestResult class
 * 
 * @author Rohit Arun
 *
 */
class TestResultTest {

	/**
	 * Tests Constructor and setter methods
	 */
	@Test
	void testTestResultTest() {

		try {
			TestResult tR = new TestResult(false, null);
			tR.isPassing();
			fail();
		} catch (Exception e) {
			assertEquals("Invalid test results.", e.getMessage());
		}

		TestResult tR1 = new TestResult(false, "actual");
		assertEquals("FAIL: actual", tR1.toString());
	}

}

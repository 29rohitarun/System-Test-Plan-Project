/**
 * 
 */
package edu.ncsu.csc216.stp.model.manager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.test_plans.AbstractTestPlan;
import edu.ncsu.csc216.stp.model.test_plans.FailingTestList;

import edu.ncsu.csc216.stp.model.tests.TestCase;

/**
 * Tests TestPlanManager class
 * 
 * @author Rohit Arun
 *
 */
class TestPlanManagerTest {

	/**
	 * Tests TestPlanManager constructor
	 */
	@Test
	void testTestPlanManager() {
		TestPlanManager tM = new TestPlanManager();
		assertFalse(tM.isChanged());
	}

	/**
	 * Tests loadTestPlans method
	 */
	@Test
	void testLoadTestPlans() {
		TestPlanManager tM = new TestPlanManager();
		File fOutput = new File("test-files/rohit_test.txt");
		tM.loadTestPlans(fOutput);
		AbstractTestPlan aTP = new FailingTestList();
		assertEquals(aTP, tM.getCurrentTestPlan());

		TestPlanManager tM1 = new TestPlanManager();
		File fOutput1 = new File("test-files/test-plans0.txt");
		File checkOutput = new File("test-files/check-output.txt");
		tM1.loadTestPlans(fOutput1);
		tM1.saveTestPlans(checkOutput);
		String[] debug = tM1.getTestPlanNames();
		assertEquals(3, debug.length);
	}

	/**
	 * Tests saveTestPlans method
	 */
	@Test
	void testSaveTestPlans() {
		TestPlanManager tM = new TestPlanManager();

		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		tM.addTestPlan("WolfScheduler");
		tM.addTestCase(tC);
		tM.addTestResult(0, true, "actual results");

		try {
			File fOutput = new File("test-files/TPMrohit_test.txt");
			tM.saveTestPlans(fOutput);
		} catch (Exception e) {
			fail("Cannot write to course records file");
		}

		checkFiles("test-files/TPMrohit_exp.txt", "test-files/TPMrohit_test.txt");

	}

	/**
	 * Tests addTestPlans method
	 */
	@Test
	void testAddTestPlan() {
		TestPlanManager tM = new TestPlanManager();
		tM.clearTestPlans();

		tM.addTestPlan("WolfScheduler");
		assertTrue(tM.isChanged());

		try {
			tM.addTestPlan("WolfScheduler");
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

		tM.clearTestPlans();

		try {
			tM.addTestPlan("Failing Tests");
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

	}

	/**
	 * Tests getTestPlanNames method
	 */
	@Test
	void testGetTestPlanNames() {
		TestPlanManager tM = new TestPlanManager();
		tM.clearTestPlans();

		tM.addTestPlan("WolfScheduler");
		tM.addTestPlan("PackScheduler");
		tM.addTestPlan("RoScheduler");
		String[] expArr = { "Failing Tests", "WolfScheduler", "PackScheduler", "RoScheduler" };
		assertEquals(expArr[0], tM.getTestPlanNames()[0]);
		assertEquals(expArr[2], tM.getTestPlanNames()[1]);
		assertEquals(expArr[3], tM.getTestPlanNames()[2]);
		assertEquals(expArr[1], tM.getTestPlanNames()[3]);
	}

	/**
	 * Tests editTestPlan method
	 */
	@Test
	void testEditTestPlan() {
		TestPlanManager tM = new TestPlanManager();
		tM.clearTestPlans();
		tM.setCurrentTestPlan("Failing Tests");

		try {
			tM.editTestPlan("WolfSceduler");
			fail();
		} catch (Exception e) {
			assertEquals("The Failing Tests list may not be edited.", e.getMessage());
		}

		tM.clearTestPlans();
		tM.addTestPlan("WolfScheduler");
		tM.setCurrentTestPlan("WolfScheduler");

		try {
			tM.editTestPlan("Failing Tests");
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

		try {
			tM.editTestPlan("WolfScheduler");
			fail();
		} catch (Exception e) {
			assertEquals("Invalid name.", e.getMessage());
		}

		tM.editTestPlan("Different");
		assertTrue(tM.isChanged());

	}

	/**
	 * Tests removeTestPlan method
	 */
	@Test
	void testRemoveTestPlan() {
		TestPlanManager tM = new TestPlanManager();
		tM.clearTestPlans();
		tM.setCurrentTestPlan("Failing Tests");

		try {
			tM.removeTestPlan();
			fail();
		} catch (Exception e) {
			assertEquals("The Failing Tests list may not be deleted.", e.getMessage());
		}

		tM.clearTestPlans();
		tM.addTestPlan("WolfScheduler");
		tM.setCurrentTestPlan("WolfScheduler");

		tM.removeTestPlan();
		assertTrue(tM.isChanged());
	}

	/**
	 * Tests addTestCase method
	 */
	@Test
	void testAddTestCase() {
		TestPlanManager tM = new TestPlanManager();
		tM.clearTestPlans();
		tM.addTestPlan("WolfScheduler");
		tM.setCurrentTestPlan("WolfScheduler");
		TestCase tC = new TestCase("id", "type", "descrip", "exp");

		tM.addTestCase(tC);
		assertTrue(tM.isChanged());

	}

	/**
	 * Helper method to compare two files for the same contents
	 * 
	 * @param expFile expected output
	 * @param actFile actual output
	 */
	private void checkFiles(String expFile, String actFile) {
		try (Scanner expScanner = new Scanner(new File(expFile));
				Scanner actScanner = new Scanner(new File(actFile));) {

			while (expScanner.hasNextLine()) {
				assertEquals(expScanner.nextLine(), actScanner.nextLine());
			}

			expScanner.close();
			actScanner.close();
		} catch (IOException e) {
			fail("Error reading files.");
		}
	}

}

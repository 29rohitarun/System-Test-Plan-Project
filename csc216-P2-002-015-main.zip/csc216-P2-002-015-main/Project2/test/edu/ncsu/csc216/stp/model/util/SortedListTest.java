/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests SortedList class
 * 
 * @author Rohit Arun
 *
 */
class SortedListTest {

	/**
	 * Tests add method
	 */
	@Test
	void testSortedListTest() {
		SortedList<String> sL = new SortedList<String>();

		try {
			sL.add(null);
			fail();
		} catch (Exception e) {
			assertEquals("Cannot add null element.", e.getMessage());
		}

		sL.add("WolfScheduler");
		assertEquals(1, sL.size());

		try {
			sL.add("WolfScheduler");
			fail();
		} catch (Exception e) {
			assertEquals("Cannot add duplicate element.", e.getMessage());
		}

		sL.add("PackScheduler");
		assertEquals(2, sL.size());

		try {
			sL.add("PackScheduler");
		} catch (Exception e) {
			assertEquals("Cannot add duplicate element.", e.getMessage());
		}

		assertEquals("PackScheduler", sL.get(0));

		sL.add("WolfPackScheduler");
		assertEquals(3, sL.size());

		sL.add("AnnaPlanner");
		assertEquals(4, sL.size());
		assertEquals("AnnaPlanner", sL.get(0));

		assertEquals("AnnaPlanner", sL.remove(0));
		assertEquals("WolfScheduler", sL.remove(2));

		try {
			sL.remove(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		assertFalse(sL.contains("NotInList"));
		assertTrue(sL.contains("PackScheduler"));

		assertEquals("WolfPackScheduler", sL.get(1));
	}

}

/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests Log class
 * 
 * @author Rohit Arun
 *
 */
class LogTest {

	/**
	 * Tests entire class
	 */
	@Test
	void testLog() {
		Log<String> l = new Log<String>();

		try {
			l.add(null);
			fail();
		} catch (Exception e) {
			assertEquals("Cannot add null element.", e.getMessage());

		}

		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("TheOne");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		l.add("WolfScheduler");
		assertEquals(11, l.size());

		try {
			l.get(-1);
			fail();
		} catch (Exception e) {
			assertEquals("Invalid index.", e.getMessage());
		}

		assertEquals("TheOne", l.get(2));

	}

}

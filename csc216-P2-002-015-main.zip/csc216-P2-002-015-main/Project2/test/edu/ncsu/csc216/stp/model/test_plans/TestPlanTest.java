/**
 * 
 */
package edu.ncsu.csc216.stp.model.test_plans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.tests.TestCase;

/**
 * Tests TestPlan class
 * 
 * @author Rohit Arun
 *
 */
class TestPlanTest {

	/**
	 * tests the getTestCasesAsArray
	 */
	@Test
	void testGetTestCasesAsArray() {
		TestPlan tP = new TestPlan("WolfScheduler");

		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		tC.addTestResult(false, "actual");
		TestCase tC1 = new TestCase("id1", "type", "descrip", "exp");
		tC1.addTestResult(true, "actual");
		TestCase tC2 = new TestCase("id2", "type", "descrip", "exp");
		tC2.addTestResult(false, "actual");
		TestCase tC3 = new TestCase("id3", "type", "descrip", "exp");
		tC3.addTestResult(true, "actual");

		tP.addTestCase(tC);
		tP.addTestCase(tC1);
		tP.addTestCase(tC2);
		tP.addTestCase(tC3);

		assertEquals(4, tP.getTestCasesAsArray().length);
		assertEquals("FAIL", tP.getTestCasesAsArray()[0][2]);
		assertEquals("PASS", tP.getTestCasesAsArray()[1][2]);
		assertEquals("type", tP.getTestCasesAsArray()[0][1]);

	}

	/**
	 * tests the addTestCase replicating TS test
	 */
	@Test
	void testAddTestCaseTS() {
		TestPlan tP = new TestPlan("Test Plan 1");

		TestCase tC = new TestCase("ID1", "type1", "description1", "expected1");
		TestCase tC1 = new TestCase("ID2", "type2", "description2", "expected2");
		TestCase tC2 = new TestCase("ID3", "type3", "description3", "expected3");
		TestCase tC3 = new TestCase("ID4", "type4", "description4", "expected4");

		tP.addTestCase(tC);
		tP.addTestCase(tC1);
		tP.addTestCase(tC2);
		tP.addTestCase(tC3);

		tP.getTestCases().moveUp(1);
		assertEquals(tC1, tP.getTestCase(0));
		assertEquals(tC, tP.getTestCase(1));

		tP.getTestCases().moveDown(2);
		assertEquals(tC2, tP.getTestCase(3));
		assertEquals(tC3, tP.getTestCase(2));

		tP.getTestCases().moveToFront(2);
		assertEquals(tC3, tP.getTestCase(0));
		
		tP.getTestCases().moveToBack(0);
		assertEquals(tC3, tP.getTestCase(3));

	}

}

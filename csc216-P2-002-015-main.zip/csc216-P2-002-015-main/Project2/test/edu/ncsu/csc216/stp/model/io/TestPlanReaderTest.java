/**
 * 
 */
package edu.ncsu.csc216.stp.model.io;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.util.ISortedList;

/**
 * Tests TestPlanReader class
 * 
 * @author Rohit Arun
 *
 */
class TestPlanReaderTest {

	/** Constant 0 of test file name */
	public static final String TF = "test-files/test-plans0.txt";
	/** Constant 1 of test file name */
	public static final String TF1 = "test-files/test-plans8.txt";
	/** Constant 2 of test file name */
	public static final String TF2 = "test-files/test-plans1.txt";
	/** Constant 2 of test file name */
	public static final String TF3 = "test-files/test-plans3.txt";

	/**
	 * Tests TestPlanReader file
	 */
	@Test
	void testReader() {
		File file = new File(TF);

		ISortedList<TestPlan> testPlans = TestPlanReader.readTestPlansFile(file);
		assertEquals(2, testPlans.size());

		File file1 = new File(TF1);

		ISortedList<TestPlan> testPlans1 = TestPlanReader.readTestPlansFile(file1);
		assertEquals(0, testPlans1.get(0).getTestCases().size());
	}

	/**
	 * Tests TestPlanReader file
	 */
	@Test
	void testReader1() {
		File file = new File(TF2);

		ISortedList<TestPlan> testPlans = TestPlanReader.readTestPlansFile(file);
		assertEquals("WolfScheduler", testPlans.get(1).getTestPlanName());
		assertEquals(3, testPlans.get(1).getTestCases().size());
	}

	/**
	 * Tests TestPlanReader exceptions
	 */
	@Test
	void testExceptions() {
		try {
			TestPlanReader.readTestPlansFile(null);
			fail();
		} catch (Exception e) {
			assertEquals("Unable to load file.", e.getMessage());
		}

		File file = new File(TF3);

		try {
			TestPlanReader.readTestPlansFile(file);
			fail();
		} catch (Exception e) {
			assertEquals("Unable to load file.", e.getMessage());
		}
	}

}

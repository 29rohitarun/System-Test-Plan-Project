/**
 * 
 */
package edu.ncsu.csc216.stp.model.io;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISortedList;
import edu.ncsu.csc216.stp.model.util.SortedList;

/**
 * Tests TestPlanWriter class
 * 
 * @author Rohit Arun
 *
 */
class TestPlanWriterTest {

	@Test
	void testWriter() {
		ISortedList<TestPlan> testPlan = new SortedList<TestPlan>();
		TestPlan tP = new TestPlan("WolfScheduler");
		TestCase tC = new TestCase("id", "type", "descrip", "exp");
		tC.addTestResult(false, "actual results");
		tP.addTestCase(tC);
		testPlan.add(tP);

		TestPlan tP1 = new TestPlan("PackScheduler");
		TestCase tC1 = new TestCase("id", "type", "descrip", "exp");
		tC1.addTestResult(true, "actual results");
		tP1.addTestCase(tC1);
		testPlan.add(tP1);

		try {
			File fOutput = new File("test-files/rohit_test.txt");
			TestPlanWriter.writeTestPlanFile(fOutput, testPlan);
		} catch (Exception e) {
			fail("Cannot write to course records file");
		}

		checkFiles("test-files/rohit_exp.txt", "test-files/rohit_test.txt");
	}

	/**
	 * Helper method to compare two files for the same contents
	 * 
	 * @param expFile expected output
	 * @param actFile actual output
	 */
	private void checkFiles(String expFile, String actFile) {
		try (Scanner expScanner = new Scanner(new File(expFile));
				Scanner actScanner = new Scanner(new File(actFile));) {

			while (expScanner.hasNextLine()) {
				assertEquals(expScanner.nextLine(), actScanner.nextLine());
			}

			expScanner.close();
			actScanner.close();
		} catch (IOException e) {
			fail("Error reading files.");
		}
	}

}
